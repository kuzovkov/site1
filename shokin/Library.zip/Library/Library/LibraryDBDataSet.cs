﻿namespace Library {
    
    
    public partial class LibraryDBDataSet {
    }
}
