<?php
    require_once('include/db.conf.php');
    require_once('include/db.func.php');
    require_once('include/setting.php');