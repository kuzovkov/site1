<?php
    define( 'BASE_URL', 'http://site1.loc/db3' );
    define( 'BASE_PATH', 'c:/www3/site1/db3/' );
    define( 'DEFAULT_DB_DUMP', 'include/lab3.1.sql' );