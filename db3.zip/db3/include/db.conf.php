<?php
define('DB_NAME','lab3');
define('DB_USER','root');
define('DB_PASS','root');
define('DB_HOST','localhost');


